package hasler.fpaaapp.utils;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import hasler.fpaaapp.ControllerActivity;

public class DriverFragment extends Fragment {

    public ControllerActivity parentContext;
    public hasler.fpaaapp.utils.Driver driver;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get parent context and instructions to execute
        parentContext = (ControllerActivity) getActivity();
        driver = new hasler.fpaaapp.utils.Driver(parentContext);
    }

    public void onConnect() {
        driver.connect();
    }

    public void onDisconnect() {
        driver.disconnect();
    }

    @Override
    public void onStart() {
        super.onStart();
        onConnect();
    }

    @Override
    public void onStop() {
        onDisconnect();
        super.onStop();
    }
}
