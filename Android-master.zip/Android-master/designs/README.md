## Designs

Pre-compiled designs which can be downloaded and programmed.

 - `c4_ramp_1.zip` Sine wave input signal + C4 Ramp design, for board 18, 3.0a
 - `dac_adc_1.zip` Sine wave input signal + DAC ADC design, for board 18, 3.0a
 - `lpf_meas_1.zip` Sine wave input signal (20 Hz) + LPF design, for board 18, 3.0a