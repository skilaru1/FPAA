# FpaaApp

This driver supports Android version 15 and up. It also uses the FTDI Android driver, which can be downloaded [here](http://www.ftdichip.com/Android.htm).

Check the [Wiki](https://github.com/codekansas/FpaaApp/wiki) for a tutorial and user manual.
