package com.ftdi.javad2xxdemo.ft4222;

public class FtdiModeListInfo {
    static String[] TITLES = {
        "Information",
        "FT4222 - SPI",
        "FT4222 - I2C",
        "FT4222 - GPIO",
    };

    static String[] DIALOGUE = {
        "Device Information",
        "FT4222 SPI",
        "FT4222 I2C",
        "FT4222 GPIO",
    };
}
